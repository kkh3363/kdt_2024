package com.kdt.testauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestauthApplication.class, args);
	}

}
