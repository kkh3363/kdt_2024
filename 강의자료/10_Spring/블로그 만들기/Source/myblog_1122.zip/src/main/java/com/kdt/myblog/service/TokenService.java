package com.kdt.myblog.service;

import com.kdt.myblog.config.jwt.TokenProvider;
import com.kdt.myblog.domain.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Duration;

@RequiredArgsConstructor
@Service
public class TokenService {
    private final TokenProvider tokenProvider;
    private final RefreshTokenService refreshTokenService;
    private final UserService userService;

    public String createNewAccessToken( String refreshToken){

        // 1. 리플레시토큰 유효성 검사
        if ( !tokenProvider.validToken(refreshToken)) {
            throw new IllegalArgumentException("Invalid Refresh Token");
        }
        Long userId = refreshTokenService.findbyRefreshToken( refreshToken)
                .getUserId();
        User  user = userService.findById(userId);

        return tokenProvider.generateToken(user, Duration.ofDays(2));
    }
}
