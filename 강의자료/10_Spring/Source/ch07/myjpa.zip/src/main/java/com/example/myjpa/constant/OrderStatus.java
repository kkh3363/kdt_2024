package com.example.myjpa.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
