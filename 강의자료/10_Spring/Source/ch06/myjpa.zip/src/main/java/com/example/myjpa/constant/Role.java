package com.example.myjpa.constant;

public enum Role {
    USER, ADMIN
}
