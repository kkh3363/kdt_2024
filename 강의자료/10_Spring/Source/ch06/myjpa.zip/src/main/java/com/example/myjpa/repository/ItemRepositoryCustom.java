package com.example.myjpa.repository;

import com.example.myjpa.dto.ItemSearchDto;
import com.example.myjpa.dto.MainItemDto;
import com.example.myjpa.entity.Item;
import org.springframework.data.domain.Page;

import org.springframework.data.domain.Pageable;

public interface ItemRepositoryCustom {
    Page<Item> getAdminItemPage(ItemSearchDto itemSearchDto, Pageable pageable);

    Page<MainItemDto> getMainItemPage(ItemSearchDto itemSearchDto, Pageable pageable);
}
