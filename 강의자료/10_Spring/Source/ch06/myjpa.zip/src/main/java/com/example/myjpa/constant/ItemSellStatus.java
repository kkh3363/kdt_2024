package com.example.myjpa.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
